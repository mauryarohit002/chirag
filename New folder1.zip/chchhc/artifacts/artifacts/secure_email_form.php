<!DOCTYPE html>
<html>
<head>
<title>FeedBack Form With Email Functionality</title>
<link href="style.css" rel="stylesheet">
</head>
<!-- Body Starts Here -->
<body>
<div class="container">
<!-- Feedback Form Starts Here -->
<div id="feedback">
<!-- Heading Of The Form -->
<div class="head">
<h3>FeedBack Form</h3>
<p>This is feedback form. Send us your feedback !</p>
</div>
<!-- Feedback Form -->
<form action="mailto:mwd.chirag@gmail.com" id="form" method="post" name="form">
<input name="vname" placeholder="Your Name" type="text" value="">
<input name="vemail" placeholder="Your Email" type="text" value="">
<input name="sub" placeholder="Subject" type="text" value="">
<label>Your Suggestion/Feedback</label>
<textarea name="msg" placeholder="Type your text here..."></textarea>
<input id="send" name="submit" type="submit" value="Send Feedback">
</form>
</div>
</div>
<?php 

if (isset($_POST['submit']))
{
	$name=trim(addslashes($_POST['vname']));
	$email=trim($_POST['vemail']);
	$sub=trim($_POST['sub']);
	$massage=trim($_POST['msg']);
	$adminwebsite="mwd.chirag@gmail.com";

	$header="reply-to:$email";
	if(mail($adminwebsite,$sub,$massage,$header)){
		echo "mail send successfully";

	}else
	{
		echo "mail send fail";
		echo ".$adminwebsite." ".$sub."".$massage." ".$header.";
	}

	
}
	?>
 </body>

<!-- Feedback Form Ends Here -->
<!-- Body Ends Here -->
</html>
