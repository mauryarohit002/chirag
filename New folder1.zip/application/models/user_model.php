<?php 
 
 class User_model extends CI_Model
 {
 	
 	public  function __construct()
 	{
 		parent::__construct();
 	}
 	function index(){

 		return $this->db->get('user');
 	}
 	function insert_data($data){

			//echo "test";

			$this->db->insert("user",$data);
		}

	function deletedata($id)
		{
			$this->db->where("id",$id);
			$this->db->delete("user");
		}

	function editdata($id){

		$this->db->where("id",$id);
		$this->db->post('user');
		// return $data->row(0);
	}	
// 	function edit($id)
// {
// $this->db->where('id', $id);
// $query = $this->db->get('products');
// return $query->row(0);
// }
 }

?>