<?php  
class Log_model extends CI_model{
	public  function __construct()
 	{
 		parent::__construct();
 	}
 	function index(){

 	}
 	function insert_data($data){
 		// print_r($data);
 		$vr=$this->db->insert("users",$_POST);
 		if($vr>0)
 		return "data inserted";
 	}
 	function login($data){
 		print_r($data);
 		$a=$this->db->get_where('users','email'=>$data['email'],'pass'=>$data['pass']);
 		print_r($a);

 		 	}

}

?>