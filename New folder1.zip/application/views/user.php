<!DOCTYPE html>
<html>
<head>
	<title></title>
  <!-- <link rel="stylesheet" type="text/css" href=""> -->
  <link rel="stylesheet" type="text/css" href="assest/css/bootstrap.min.css">
  <script src="assest/js/jquery-1.12.4.min.js"></script>
  <script src="assest/js/bootstrap.min.js"></script>
</head>
<body> 

  <form method="post" action="http://localhost/CodeIgniter-3.1.9/index.php/user/insert" >
  <div class="col-md-4">
  <div class="form-group">
    <label for="email" >Name:</label>
    <input type="text" class="form-control" name="name">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" name="password">
  </div>

<div class="form-group">
  <button type="submit" class="btn btn-default">Submit</button>
 </div> 
</div>
</form> 
<?php
echo'<table class="table">
      <table class="table table-striped table-hover table-bordered">
        <thead><tr style="text-align:center;">

        <th style="text-align:center;"><h4>Id</h4></th>
        <th style="text-align:center;"><h4>Email</h4></th>
        <th style="text-align:center;"><h4>Name</h4></th>
        <th style="text-align:center;" colspan="2"><h4>Action</h4></th>
       
        </tr></thead><tbody>';
  foreach($userlist->result() as $re){

    echo '<tr style="text-align:center;">
              <td>'.$re->id.'</td>
              <td>'.$re->email.'</td>
              <td>'.$re->name.'</td>
              <td><a type="button" class="btn btn-success" href="'.base_url('index.php/user/delete/'.$re->id).'">Delete</a></td>
              <td><a type="button" class="btn btn-success eid" data-toggle="modal" data-target="#myModal" href="'.base_url('index.php/user/edit/'.$re->id).'">Edit</a></td>
             </tr>'; 
    
}
 echo '</tbody>
        </table>';       
?>        
       
        
               
              <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                 
                 <div class="modal-content">
              <div class="modal-header">
                 
                <form method="post" action="'.base_url('index.php/user/edit/'.$id).'" >
                 <div class="col-md-4">
               <div class="form-group">
                <label for="id" >ID:</label>
                  <input type="text" class="form-control" name="id" value=""/>
                </div>
              <div class="form-group">
            <label for="email" >Name:</label>
                  <input type="text" class="form-control" name="name" value="">
               </div>
                 <div class="form-group">
                  <label for="email">Email address:</label>
                   <input type="email" class="form-control" name="email" value="">
            </div>';
                 <div class="form-group">
            <label for="pwd">Password:</label>
                  <input type="password" class="form-control" name="password" value="">
              </div>

             <div class="form-group">
                 <button type="submit" class="btn btn-default">Update</button>
            
              
       </div>
          </div>
       </form>
       
 </div>

  </div>
</div>
</body>
</html>


<script type="text/javascript">
  $(".eid").click(function(){
    // alert();
    for(i=0;i<4;i++){
    var b=$(this).parent().parent().find("td:eq("+i+")").html();
    // alert(b);
    $(".modal-header input:eq("+i+")").val(b);
  }

  })
  
</script>