
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Create extends CI_Controller{
	public function __construct(){
		parent::__construct();
	}

	function index(){
		// echo"hi";
		$this->load->view('login');
		
	}
	function insert(){
		// print_r($_POST);
		$this->load->model('log_model');
		$res=$this->log_model->insert_data($_POST);
		// $vr=$this->db->insert("users",$_POST);
	// print_r($res);

			redirect(base_url());
		}
	function login(){
		$this->load->model('log_model');
		$this->log_model->login($_POST);
	}

}

 ?>