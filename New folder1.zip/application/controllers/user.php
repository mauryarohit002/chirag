  <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	
	public function __construct(){
		parent::__construct();
	}
	function index()
	{
		// $this->load->view('user');
		$this->load->model('user_model');
		$result=$this->user_model->index();
		$data=array('userlist'=>$result);
		$this->load->view("user",$data);
	}
	
	function insert(){

			// print_r($_POST);
			$this->load->model('user_model');
			$this->user_model->insert_data($_POST);
			redirect(base_url());
		}
		function delete($id)
		{
			// echo $id;
			$this->load->model('user_model');
			$this->user_model->deletedata($id);
			redirect(base_url());
		}

		function edit($id){

			echo $id;
			$this->load->model('user_model');
			$this->user_model->editdata($id);
			// $id=$this->input->get('id');
			// // echo $id ;
			// $this->load->model('user_model');
			// $data=$this->user_model->edit('$id');
		 //    $this->load->view("user",$data);

		}
// 		function edit($id)
// {
//     $data['title'] = "Edit Product";
//     $data['product_data'] = $this->model->edit($id);
//     $this->load->view('productEdit', $data);
// }



}